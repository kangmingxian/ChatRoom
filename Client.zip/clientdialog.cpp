#include "clientdialog.h"
#include "ui_clientdialog.h"

ClientDialog::ClientDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ClientDialog)
{
    ui->setupUi(this);
    status = false;//离线状态
    connect(&tcpSocket,SIGNAL(connected()),this,SLOT(onConnected()));
    connect(&tcpSocket,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
    connect(&tcpSocket,SIGNAL(readyRead()),this,SLOT(onReadyRead()));
    connect(&tcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,
            SLOT(onError()));
}

ClientDialog::~ClientDialog()
{
    delete ui;
}

//发送按钮对应的槽函数
void ClientDialog::on_sendButton_clicked()
{
    QString msg = ui->messageEdit->text();
    if(msg==""){
        return;
    }else{
        msg = username +":"+msg;
        tcpSocket.write(msg.toUtf8());
        ui->messageEdit->clear();
    }
}
//连接服务器按钮对应的槽函数
void ClientDialog::on_connectButton_clicked()
{
    if(status == false){
        //获取服务器IP
        serverIP.setAddress(ui->serverIpEdit->text());
        //获取服务器端口
        serverPort = ui->serverPortEdit->text().toShort();
        //获取聊天室昵称
        username = ui->userNameEdit->text();
        //向服务器发送连接请求
        tcpSocket.connectToHost(serverIP,serverPort);
    }else{
        //向服务器发送离开聊天室的提示信息
        QString msg = username +"离开了聊天室";
        tcpSocket.write(msg.toUtf8());
        tcpSocket.disconnectFromHost();
    }
}

//和服务器连接成功时执行的槽函数
void ClientDialog::onConnected()
{
    status = true;
    ui->sendButton->setEnabled(true);
    ui->serverIpEdit->setEnabled(false);
    ui->serverPortEdit->setEnabled(false);
    ui->userNameEdit->setEnabled(false);
    ui->connectButton->setText("离开聊天室");

    //向服务器发送进入聊天室提示信息
    QString msg = username +"进入了聊天室";
    tcpSocket.write(msg.toUtf8());
}
//和服务器连接断开时执行的槽函数
void ClientDialog::onDisconnected()
{
    status = false;
    ui->sendButton->setEnabled(false);
    ui->serverIpEdit->setEnabled(true);
    ui->serverPortEdit->setEnabled(true);
    ui->userNameEdit->setEnabled(true);
    ui->connectButton->setText("连接服务器");
}
//接收聊天信息的槽函数
void ClientDialog::onReadyRead()
{
    if(tcpSocket.bytesAvailable()){
        //接收消息
        QByteArray buf = tcpSocket.readAll();
        ui->listWidget->addItem(buf);
        ui->listWidget->scrollToBottom();
    }
}
//网络异常时执行的槽函数
void ClientDialog::onError()
{
    QMessageBox::critical(this,"ERROR",tcpSocket.errorString());
}
